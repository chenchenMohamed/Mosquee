import { BrowserModule } from '@angular/platform-browser';

import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { AccueilComponent } from './pages/accueil/accueil.component';
import { PresentationComponent } from './pages/presentation/presentation.component';
import { MissionActivitesComponent } from './pages/mission-activites/mission-activites.component';

import { IslamComponent } from './pages/islam/islam.component';
import { HoraireDesPrieresComponent } from './pages/horaire-des-prieres/horaire-des-prieres.component';
import { FooterComponent } from './components/footer/footer.component';
import { HttpModule } from "@angular/http"

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { FetesComponent } from './pages/fetes/fetes.component';
import { FaireDonComponent } from './pages/faire-don/faire-don.component';
import { LoginComponent } from './admin/login/login.component';
import { ActualitesComponent } from './admin/actualites/actualites.component';
import { ActivitesComponent } from './admin/activites/activites.component';
import { CommuniquesComponent } from './admin/communiques/communiques.component';
import { ProfilComponent } from './admin/profil/profil.component';
import { PhotosComponent } from './admin/photos/photos.component';
import { VideosComponent } from './admin/videos/videos.component';
import { AddVideoComponent } from './admin/add-video/add-video.component';
import { AddPhotoComponent } from './admin/add-photo/add-photo.component';
import { AddActiviteComponent } from './admin/add-activite/add-activite.component';
import { AddCommuniqueComponent } from './admin/add-communique/add-communique.component';
import { DeleteCommuniqueComponent } from './admin/delete-communique/delete-communique.component';
import { DeleteActualiteComponent } from './admin/delete-actualite/delete-actualite.component';
import { DeleteActiviteComponent } from './admin/delete-activite/delete-activite.component';
import { DeletePhotoComponent } from './admin/delete-photo/delete-photo.component';
import { DeleteVideoComponent } from './admin/delete-video/delete-video.component';
import { UpdateCommuniqueComponent } from './admin/update-communique/update-communique.component';
import { UpdateActualiteComponent } from './admin/update-actualite/update-actualite.component';
import { UpdateActiviteComponent } from './admin/update-activite/update-activite.component';
import { UpdatePhotoComponent } from './admin/update-photo/update-photo.component';
import { UpdateVideoComponent } from './admin/update-video/update-video.component';
import { LoadingComponent } from './components/loading/loading.component';
import { AddActualiteComponent } from './admin/add-actualite/add-actualite.component';
import { PaginationComponent } from './components/pagination/pagination.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { MecqueComponent } from './pages/mecque/mecque.component';
import { SunnaComponent } from './pages/sunna/sunna.component';
import { CoranComponent } from './pages/coran/coran.component';
import { ProphetesComponent } from './pages/prophetes/prophetes.component';
import { InvocationsComponent } from './pages/invocations/invocations.component';
import { JoursHijjaComponent } from './pages/jours-hijja/jours-hijja.component';
import { ActualitesMosqueComponent } from './pages/actualites-mosque/actualites-mosque.component';
import { VideosMosqueComponent } from './pages/videos-mosque/videos-mosque.component';
import { PhotosMosqueComponent } from './pages/photos-mosque/photos-mosque.component';
import { CommuniquesMosqueComponent } from './pages/communiques-mosque/communiques-mosque.component';
import { AccueilBarComponent } from './components/accueil-bar/accueil-bar.component';
import { PubliciteComponent } from './components/publicite/publicite.component';
import { SafePipe } from './safe-pipe/safe-pipe.component';
import { ItemActualiteComponent } from './components/item-actualite/item-actualite.component';
import { RegulieusesComponent } from './admin/regulieuses/regulieuses.component';
import { ItemCoranComponent } from './components/item-coran/item-coran.component';
import { ItemCommuniqueComponent } from './components/item-communique/item-communique.component';
import { SadakaComponent } from './pages/sadaka/sadaka.component';
import { ContactComponent } from './pages/contact/contact.component';
import { JoursComponent } from './admin/jours/jours.component';
import { UpdateJourComponent } from './admin/update-jour/update-jour.component';
import { ItemParticiperComponent } from './components/item-participer/item-participer.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    AccueilComponent,
    PresentationComponent,
    MissionActivitesComponent,
    IslamComponent,
    HoraireDesPrieresComponent,
    FooterComponent,
    FetesComponent,
    FaireDonComponent,
    LoginComponent,
    ActualitesComponent,
    ActivitesComponent,
    CommuniquesComponent,
    ProfilComponent,
    PhotosComponent,
    VideosComponent,
    AddVideoComponent,
    AddPhotoComponent,
    AddActiviteComponent,
    AddCommuniqueComponent,
    DeleteCommuniqueComponent,
    DeleteActualiteComponent,
    DeleteActiviteComponent,
    DeletePhotoComponent,
    DeleteVideoComponent,
    UpdateCommuniqueComponent,
    UpdateActualiteComponent,
    UpdateActiviteComponent,
    UpdatePhotoComponent,
    UpdateVideoComponent,
    LoadingComponent,
    AddActualiteComponent,
    PaginationComponent,
    SidebarComponent,
    MecqueComponent,
    SunnaComponent,
    CoranComponent,
    ProphetesComponent,
    InvocationsComponent,
    JoursHijjaComponent,
    ActualitesMosqueComponent,
    VideosMosqueComponent,
    PhotosMosqueComponent,
    CommuniquesMosqueComponent,
    AccueilBarComponent,
    PubliciteComponent,
    SafePipe,
    ItemActualiteComponent,
    RegulieusesComponent,
    ItemCoranComponent,
    ItemCommuniqueComponent,
    SadakaComponent,
    ContactComponent,
    JoursComponent,
    UpdateJourComponent,
    ItemParticiperComponent,
  ],
  imports: [
    HttpModule,
    BrowserModule,
    AppRoutingModule,
    FontAwesomeModule,
    FormsModule,
    ReactiveFormsModule, 
    NgbModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
