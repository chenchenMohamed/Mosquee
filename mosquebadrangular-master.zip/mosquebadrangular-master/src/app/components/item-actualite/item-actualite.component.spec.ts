import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemActualiteComponent } from './item-actualite.component';

describe('ItemActualiteComponent', () => {
  let component: ItemActualiteComponent;
  let fixture: ComponentFixture<ItemActualiteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemActualiteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemActualiteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
