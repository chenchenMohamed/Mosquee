import { Component, OnInit, Input, SimpleChanges , Output, EventEmitter } from '@angular/core';
import { faHeart } from '@fortawesome/free-solid-svg-icons';
import { ActualitesService } from '../../services/actualites.service';

@Component({
  selector: 'app-item-actualite',
  templateUrl: './item-actualite.component.html',
  styleUrls: ['./item-actualite.component.scss']
})
export class ItemActualiteComponent implements OnInit {
  faHeart = faHeart;
  @Input() item;

  isLove

  isLoading = false

  constructor(private serv:ActualitesService) {
    
   }


  ngOnInit(): void {
    this.isLove = this.serv.verifierAuListLove(this.item)
  }

  changeLove(){
  
    if(!this.isLoading){
      this.isLoading = true
      this.serv.ajouterListLove(this.item)
      this.serv.id = this.item.id
      
      if(this.isLove){
        this.isLove = false
        this.serv.enleveLove().subscribe(res=>{
          if(res.status){
            this.item.numberOfLove = this.item.numberOfLove - 1
            this.isLoading = false
          }
        },err=>{
          this.isLoading = false
        })
      }else{
        this.isLove = true
        this.serv.ajouterLove().subscribe(res=>{
          if(res.status){
            this.item.numberOfLove = this.item.numberOfLove + 1
            this.isLoading = false
          }
        },err=>{
          this.isLoading = false
        })
      }
        
    }
  }

}
