import { Component, OnInit, HostBinding } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
 
  
  tabRoutesDashboard = ["/actualites", "/activites", "/communiques", "/photos", "/videos"]
 
  classNavbarToggleShow = "style-navbar-mobile"
  isDashboard = false
  constructor(private router : Router) { }

  ngOnInit(): void {

    this.router.events.subscribe((val) => {
      // see also 
      if(val instanceof NavigationEnd){
        var ok = false
        for(var i=0; i<this.tabRoutesDashboard.length;i++ ){
             if(this.tabRoutesDashboard[i] == val.url){
               ok=true
             }
        }
        this.isDashboard = ok
      } 
  });

  }

  showSousListe(pos){
    var elemts = document.getElementsByClassName('sous-menu-mobile');

    for(let i=0; i<elemts.length; i++ ){
      elemts[i].classList.remove("style-navbar-mobile-active2");
    }

    elemts[pos].classList.add("style-navbar-mobile-active2");
  }

  toggleNavbarShow(){
    if(this.classNavbarToggleShow == "style-navbar-mobile style-navbar-mobile-active"){
      this.classNavbarToggleShow = "style-navbar-mobile"
    }else{
      var elemts = document.getElementsByClassName('sous-menu-mobile');

      for(let i=0; i<elemts.length; i++ ){
        elemts[i].classList.remove("style-navbar-mobile-active2");
      }
      
      this.classNavbarToggleShow = "style-navbar-mobile style-navbar-mobile-active"
    }
  }

}
