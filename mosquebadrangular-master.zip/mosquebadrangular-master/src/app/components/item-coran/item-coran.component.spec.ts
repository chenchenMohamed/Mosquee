import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemCoranComponent } from './item-coran.component';

describe('ItemCoranComponent', () => {
  let component: ItemCoranComponent;
  let fixture: ComponentFixture<ItemCoranComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemCoranComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemCoranComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
