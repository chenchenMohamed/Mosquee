import { Component, OnInit,  Input } from '@angular/core';

@Component({
  selector: 'app-item-coran',
  templateUrl: './item-coran.component.html',
  styleUrls: ['./item-coran.component.scss']
})
export class ItemCoranComponent implements OnInit {

  @Input() audio:string;
  @Input() titre:string;
  @Input() description:string;
  @Input() versets:string;
  

  constructor() { }

  ngOnInit(): void {
  }

}
