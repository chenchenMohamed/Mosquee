import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivitesService } from '../../services/activites.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-item-participer',
  templateUrl: './item-participer.component.html',
  styleUrls: ['./item-participer.component.scss']
})
export class ItemParticiperComponent implements OnInit {

  formE:FormGroup
  activite
   
  constructor(private serv:ActivitesService, private Fb:FormBuilder, public activeModal: NgbActiveModal) {
    this.activite = this.serv.getItem() 
  }
  
  ngOnInit() {
    this.formE=this.Fb.group({
      nom:['',[Validators.required]],
      email:['',[Validators.required]],
      telephone:['',[Validators.required]],
    })
  }
  
 ajouter(){
  
     var subject = "Nouveau Paricipant"
     var nom = this.formE.value.nom
     var email = this.formE.value.email
     var telephone = this.formE.value.telephone
     var message = "\r\n Titre d'activite :"+this.activite.titre + "\r\n Description d'activite : "+this.activite.description+"\r\n Duree d'activite : "+this.activite.duree+"\r\n Date d'activite : "+this.activite.date+"\r\n Prix d'activite : "+this.activite.prix
     let obj ={subject:subject, nom:nom, email:email, telephone:telephone, message:message}

      this.serv.newParticipant(obj).subscribe(res => {
        if(res.status){
          this.serv.setLoading()
          alert("Votre inscription est envoyée")
        //  this.formC.reset()
        }
      })
    
    this.activeModal.close()
  }

}
