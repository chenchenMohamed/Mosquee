import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemParticiperComponent } from './item-participer.component';

describe('ItemParticiperComponent', () => {
  let component: ItemParticiperComponent;
  let fixture: ComponentFixture<ItemParticiperComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemParticiperComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemParticiperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
