import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-publicite',
  templateUrl: './publicite.component.html',
  styleUrls: ['./publicite.component.scss']
})
export class PubliciteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
