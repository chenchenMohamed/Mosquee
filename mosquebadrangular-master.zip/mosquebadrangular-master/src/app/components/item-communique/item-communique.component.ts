import { Component, OnInit, Input, SimpleChanges , Output, EventEmitter } from '@angular/core';
import { faHeart } from '@fortawesome/free-solid-svg-icons';
import { CommuniquesService } from '../../services/communiques.service';

@Component({
  selector: 'app-item-communique',
  templateUrl: './item-communique.component.html',
  styleUrls: ['./item-communique.component.scss']
})
export class ItemCommuniqueComponent implements OnInit {
  faHeart = faHeart;
  @Input() item;

  isLove

  isLoading = false

  constructor(private serv:CommuniquesService) {
    
   }


  ngOnInit(): void {
    this.isLove = this.serv.verifierAuListLove(this.item)
  }

  changeLove(){
  
    if(!this.isLoading){
      this.isLoading = true
      this.serv.ajouterListLove(this.item)
      this.serv.id = this.item.id
      
      if(this.isLove){
        this.isLove = false
        this.serv.enleveLove().subscribe(res=>{
          if(res.status){
            this.item.numberOfLove = this.item.numberOfLove - 1
            this.isLoading = false
          }
        },err=>{
          this.isLoading = false
        })
      }else{
        this.isLove = true
        this.serv.ajouterLove().subscribe(res=>{
          if(res.status){
            this.item.numberOfLove = this.item.numberOfLove + 1
            this.isLoading = false
          }
        },err=>{
          this.isLoading = false
        })
      }
        
    }
  }
}

