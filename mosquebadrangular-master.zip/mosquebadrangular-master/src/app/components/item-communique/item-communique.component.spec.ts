import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemCommuniqueComponent } from './item-communique.component';

describe('ItemCommuniqueComponent', () => {
  let component: ItemCommuniqueComponent;
  let fixture: ComponentFixture<ItemCommuniqueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemCommuniqueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemCommuniqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
