
import { Component, OnInit, Input, SimpleChanges , Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-accueil-bar',
  templateUrl: './accueil-bar.component.html',
  styleUrls: ['./accueil-bar.component.scss']
})
export class AccueilBarComponent implements OnInit {

  @Input() page: string;
  @Input() image: string;

  style
  constructor() { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    this.style = "background-image: url("+this.image+"); "
  }
}
