import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SadakaComponent } from './sadaka.component';

describe('SadakaComponent', () => {
  let component: SadakaComponent;
  let fixture: ComponentFixture<SadakaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SadakaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SadakaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
