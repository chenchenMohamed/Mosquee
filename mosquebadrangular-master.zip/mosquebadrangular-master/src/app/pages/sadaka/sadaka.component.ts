import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sadaka',
  templateUrl: './sadaka.component.html',
  styleUrls: ['./sadaka.component.scss']
})
export class SadakaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
