import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invocations',
  templateUrl: './invocations.component.html',
  styleUrls: ['./invocations.component.scss']
})
export class InvocationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
