import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prophetes',
  templateUrl: './prophetes.component.html',
  styleUrls: ['./prophetes.component.scss']
})
export class ProphetesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
