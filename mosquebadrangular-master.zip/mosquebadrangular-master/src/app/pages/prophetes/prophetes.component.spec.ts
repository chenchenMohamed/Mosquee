import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProphetesComponent } from './prophetes.component';

describe('ProphetesComponent', () => {
  let component: ProphetesComponent;
  let fixture: ComponentFixture<ProphetesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProphetesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProphetesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
