import { Component, OnInit } from '@angular/core';
import { JoursService } from '../../services/jours.service';
declare var $: any;
import {formatDate} from '@angular/common';

@Component({
  selector: 'app-horaire-des-prieres',
  templateUrl: './horaire-des-prieres.component.html',
  styleUrls: ['./horaire-des-prieres.component.scss']
})
export class HoraireDesPrieresComponent implements OnInit {

  constructor(private serv:JoursService) { }

  tabJoursOriginal = []
  tabJours = []
  mois = "1"
  date = formatDate(new Date(), 'dd-MM-yyyy', 'en');
  dayNow
   
  ngOnInit(): void {
    var moisVersion1  = this.date.substring(3,6)
    var position = moisVersion1.indexOf("-")
    this.mois = moisVersion1.substring(0,position)
    
    this.serv.listJours().subscribe(res=>{
       this.tabJoursOriginal = res.resultat
       var tabJoursCopie = this.tabJoursOriginal
       
       for(let i=0; i<tabJoursCopie.length; i++){
          if(tabJoursCopie[i].date == this.date){
             this.dayNow = tabJoursCopie[i]
             this.dayNow.isNow = true
             this.tabJoursOriginal[i] = this.dayNow   
          }else{
            var dayNow2 = tabJoursCopie[i]
            dayNow2.isNow = false
            this.tabJoursOriginal[i] = dayNow2
          }
       }

       this.tabJours = tabJoursCopie.filter(x => x.month == this.mois)    
       
    })

    $('#'+this.mois).addClass("style-li-active")

  }

  changeMois(event){
    $('#'+this.date).addClass("style-li-active")
    $('#'+this.mois).removeClass("style-li-active")
    this.mois = event.target.id 
    $('#'+this.mois).addClass("style-li-active")
    var tabJoursCopie = this.tabJoursOriginal
    this.tabJours = tabJoursCopie.filter(x => x.month == this.mois)    
  }  

}
