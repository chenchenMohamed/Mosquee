import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HoraireDesPrieresComponent } from './horaire-des-prieres.component';

describe('HoraireDesPrieresComponent', () => {
  let component: HoraireDesPrieresComponent;
  let fixture: ComponentFixture<HoraireDesPrieresComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HoraireDesPrieresComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HoraireDesPrieresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
