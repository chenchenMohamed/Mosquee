import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-islam',
  templateUrl: './islam.component.html',
  styleUrls: ['./islam.component.scss']
})
export class IslamComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
