import { Component, OnInit } from '@angular/core';
import { ActivitesService } from '../../services/activites.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ItemParticiperComponent } from '../../components/item-participer/item-participer.component';

@Component({
  selector: 'app-mission-activites',
  templateUrl: './mission-activites.component.html',
  styleUrls: ['./mission-activites.component.scss']
})
export class MissionActivitesComponent implements OnInit {
  tabListe = []
  
  constructor(private modalService: NgbModal, private serv:ActivitesService) { }

  ngOnInit(): void {
    this.serv.listAll().subscribe(res => {
      if(res.status){
        this.serv.setListe(res.resultat)
        this.tabListe = res.resultat
      }
    })
  }

  openParticipant(event){ 
    this.serv.id = event.target.id
    const modalRef = this.modalService.open(ItemParticiperComponent, {size:"lg"});
    modalRef.componentInstance.name = 'World';
  }

}