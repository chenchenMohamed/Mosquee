import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MissionActivitesComponent } from './mission-activites.component';

describe('MissionActivitesComponent', () => {
  let component: MissionActivitesComponent;
  let fixture: ComponentFixture<MissionActivitesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MissionActivitesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MissionActivitesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
