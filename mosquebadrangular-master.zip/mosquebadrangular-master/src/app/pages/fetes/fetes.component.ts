import { Component, OnInit } from '@angular/core';
import { JoursService } from '../../services/jours.service';

@Component({
  selector: 'app-fetes',
  templateUrl: './fetes.component.html',
  styleUrls: ['./fetes.component.scss']
})
export class FetesComponent implements OnInit {

  item

  constructor(private serv:JoursService) { }
  
  ngOnInit(): void {
    this.serv.listRegulieuses().subscribe(res => {
      if(res.status){
         var liste = res.resultat
         if(liste.length>0){
           this.item = liste[0]
         }
      }

    })
  }

}
