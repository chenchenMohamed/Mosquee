import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FetesComponent } from './fetes.component';

describe('FetesComponent', () => {
  let component: FetesComponent;
  let fixture: ComponentFixture<FetesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FetesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FetesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
