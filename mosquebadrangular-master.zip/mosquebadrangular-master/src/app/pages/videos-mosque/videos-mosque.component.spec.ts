import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VideosMosqueComponent } from './videos-mosque.component';

describe('VideosMosqueComponent', () => {
  let component: VideosMosqueComponent;
  let fixture: ComponentFixture<VideosMosqueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VideosMosqueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VideosMosqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
