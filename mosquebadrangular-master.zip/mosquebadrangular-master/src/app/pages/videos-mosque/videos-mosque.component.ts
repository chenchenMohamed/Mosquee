import { Component, OnInit } from '@angular/core';
import { VideosService } from '../../services/videos.service';

@Component({
  selector: 'app-videos-mosque',
  templateUrl: './videos-mosque.component.html',
  styleUrls: ['./videos-mosque.component.scss']
})
export class VideosMosqueComponent implements OnInit {
  tabListe = []
             
               
  constructor(private serv:VideosService) { }

  ngOnInit(): void {
    this.serv.listAll().subscribe(res => {
      if(res.status){
        
        this.tabListe = res.resultat
        console.log(this.tabListe)
      }
    })
  }

}
