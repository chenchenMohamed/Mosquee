import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sunna',
  templateUrl: './sunna.component.html',
  styleUrls: ['./sunna.component.scss']
})
export class SunnaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
