import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommuniquesMosqueComponent } from './communiques-mosque.component';

describe('CommuniquesMosqueComponent', () => {
  let component: CommuniquesMosqueComponent;
  let fixture: ComponentFixture<CommuniquesMosqueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommuniquesMosqueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommuniquesMosqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
