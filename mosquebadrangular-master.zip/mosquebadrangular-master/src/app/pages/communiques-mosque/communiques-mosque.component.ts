import { Component, OnInit } from '@angular/core';
import { CommuniquesService } from '../../services/communiques.service';

@Component({
  selector: 'app-communiques-mosque',
  templateUrl: './communiques-mosque.component.html',
  styleUrls: ['./communiques-mosque.component.scss']
})

export class CommuniquesMosqueComponent implements OnInit {
  tabListe = []
  
  constructor(private serv:CommuniquesService) { }

  ngOnInit(): void {
    this.serv.listAll().subscribe(res => {
      if(res.status){
        
        this.tabListe = res.resultat
      
      }
    })
  }

}