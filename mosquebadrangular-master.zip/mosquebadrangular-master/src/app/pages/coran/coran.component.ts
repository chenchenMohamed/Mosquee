import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coran',
  templateUrl: './coran.component.html',
  styleUrls: ['./coran.component.scss']
})
export class CoranComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
