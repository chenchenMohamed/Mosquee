import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActualitesMosqueComponent } from './actualites-mosque.component';

describe('ActualitesMosqueComponent', () => {
  let component: ActualitesMosqueComponent;
  let fixture: ComponentFixture<ActualitesMosqueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ActualitesMosqueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActualitesMosqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
