import { Component, OnInit } from '@angular/core';

import { ActualitesService } from '../../services/actualites.service';


@Component({
  selector: 'app-actualites-mosque',
  templateUrl: './actualites-mosque.component.html',
  styleUrls: ['./actualites-mosque.component.scss']
})
export class ActualitesMosqueComponent implements OnInit {
  tabListe = []
  
  constructor(private serv:ActualitesService) { }

  ngOnInit(): void {
    this.serv.listAll().subscribe(res => {
      if(res.status){
        
        this.tabListe = res.resultat
      
      }
    })
  }

}