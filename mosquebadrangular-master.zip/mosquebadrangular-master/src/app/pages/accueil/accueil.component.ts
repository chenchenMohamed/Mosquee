import { Component, OnInit } from '@angular/core';
import { JoursService } from '../../services/jours.service';
declare var $: any;
import {formatDate} from '@angular/common';
import { interval, timer } from 'rxjs';
import { faHeart } from '@fortawesome/free-solid-svg-icons';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UsersService } from '../../services/users.service';

@Component({
  selector: 'app-accueil',
  templateUrl: './accueil.component.html',
  styleUrls: ['./accueil.component.scss']
})

export class AccueilComponent implements OnInit {
  faHeart = faHeart;
  now
  formC:FormGroup

  constructor(private serv:JoursService, private serv2:UsersService, private fb:FormBuilder) { 
    setInterval(() => {
      this.now = Date.now();
    }, 1);

    this.formC=this.fb.group({
      email:['',[Validators.required, Validators.minLength(1)]],
    })
  }

  

  tabJoursOriginal = []
  date = formatDate(new Date(), 'dd-MM-yyyy', 'en');
  dayNow
  priere
  timeRestant

  actualites
  communiques
  photos
  videos

  classFajr="style-div-priere"
  classDhuhr="style-div-priere"
  classAsr="style-div-priere"
  classMogrob="style-div-priere"
  classIsha="style-div-priere"

  ngOnInit(): void {
   
    const timer = interval(60000);

    
    
    timer.subscribe((n) => {
     
      this.calculateTimeRestant()
  
    })

    this.serv.getAcceuil().subscribe(res=>{
      if(res.status){
        this.actualites = res.actualites
        this.communiques = res.communiques
        this.photos = res.photos
        this.videos = res.videos
      }
    })
    
  
  this.serv.listJours().subscribe(res=>{
      this.tabJoursOriginal = res.resultat
      var tabJoursCopie = this.tabJoursOriginal
       
      for(let i=0; i<tabJoursCopie.length; i++){
          if(tabJoursCopie[i].date == this.date){
             this.dayNow = tabJoursCopie[i]
          }
      }

      this.calculateTimeRestant()
    })
  
  }

  calculateTimeRestant(){
    this.classFajr="style-div-priere"
    this.classDhuhr="style-div-priere"
    this.classAsr="style-div-priere"
    this.classMogrob="style-div-priere"
    this.classIsha="style-div-priere"
  

     var time = formatDate(new Date(), 'HH:mm', 'en');
     var heure1 = time.substring(0,2)
     var minute1 = time.substring(3,5)
     var heureNumber1: number = +heure1
     var minuteNumber1: number = +minute1
     
     var heure2 = this.dayNow.fajr.substring(0,2)
     var minute2 = this.dayNow.fajr.substring(3,5)
     var heureNumber2: number = +heure2
     var minuteNumber2: number = +minute2

     var heure3 = this.dayNow.dhuhr.substring(0,2)
     var minute3 = this.dayNow.dhuhr.substring(3,5)
     var heureNumber3: number = +heure3
     var minuteNumber3: number = +minute3

     var heure4 = this.dayNow.asr.substring(0,2)
     var minute4 = this.dayNow.asr.substring(3,5)
     var heureNumber4: number = +heure4
     var minuteNumber4: number = +minute4

     var heure5 = this.dayNow.maghrib.substring(0,2)
     var minute5 = this.dayNow.maghrib.substring(3,5)
     var heureNumber5: number = +heure5
     var minuteNumber5: number = +minute5

     var heure6 = this.dayNow.isha.substring(0,2)
     var minute6 = this.dayNow.isha.substring(3,5)
     var heureNumber6: number = +heure6
     var minuteNumber6: number = +minute6

  
    if( ((heureNumber1 < heureNumber2) || (heureNumber1 == heureNumber2 && minuteNumber1 < minuteNumber2+1) ) || (heureNumber1 > heureNumber6 || (heureNumber1 == heureNumber6 && minuteNumber1 > minuteNumber6)) ){
       this.priere = "Fajr"  
       this.moinHeure(heureNumber1,minuteNumber1,heureNumber2,minuteNumber2)
       this.classFajr = "style-div-priere style-div-priere-active";
    }else if( (heureNumber1 > heureNumber2 || (heureNumber1 == heureNumber2 && minuteNumber1+1 > minuteNumber2) ) && (heureNumber1 < heureNumber3 || (heureNumber1 == heureNumber3 && minuteNumber1 < minuteNumber3+1)) ){
      this.priere = "Dhuhr"      
      this.moinHeure(heureNumber1,minuteNumber1,heureNumber3,minuteNumber3)
      this.classDhuhr = "style-div-priere style-div-priere-active";
    }else if( (heureNumber1 > heureNumber3 || (heureNumber1 == heureNumber3 && minuteNumber1 > minuteNumber3)) && (heureNumber1 < heureNumber4 || (heureNumber1 == heureNumber4 && minuteNumber1 < minuteNumber4+1)) ){
      this.priere = "Asr"      
      this.moinHeure(heureNumber1,minuteNumber1,heureNumber4,minuteNumber4)
      this.classAsr = "style-div-priere style-div-priere-active";
    }else if( (heureNumber1 > heureNumber4 || (heureNumber1 == heureNumber4 && minuteNumber1 > minuteNumber4)) && (heureNumber1 < heureNumber5 || (heureNumber1 == heureNumber5 && minuteNumber1 < minuteNumber5+1)) ){
      this.priere = "Maghrib"      
      this.moinHeure(heureNumber1,minuteNumber1,heureNumber5,minuteNumber5)
      this.classMogrob = "style-div-priere style-div-priere-active";
    }else if( (heureNumber1 > heureNumber5 || (heureNumber1 == heureNumber5 && minuteNumber1 < minuteNumber5+1)) && (heureNumber1 < heureNumber6 || (heureNumber1 == heureNumber6 && minuteNumber1 < minuteNumber6+1)) ){
      this.priere = "Isha"      
      this.moinHeure(heureNumber1,minuteNumber1,heureNumber6,minuteNumber6)
      this.classIsha = "style-div-priere style-div-priere-active";
    }
    
  }

moinHeure(heure1, minute1, heure2, minute2){
  var heureResultat
  var minuteResultat
  
  if(heure1 > heure2){
    heureResultat = (24 - heure1) + heure2
    minuteResultat = minute2 - minute1
    if(minuteResultat < 0){
      minuteResultat += 60
      heureResultat -= 1  
    }
  }else{
    heureResultat =  heure2 - heure1
    minuteResultat = minute2 - minute1
    if(minuteResultat < 0){
      minuteResultat += 60
      heureResultat -= 1  
    }
  }
  console.log(heureResultat)
  if(minuteResultat < 10){
      this.timeRestant = heureResultat+"h:0"+minuteResultat
  }else{
      this.timeRestant = heureResultat+"h:"+minuteResultat
  }
}

subscribe(){
  if(this.controleInput(this.formC.value)){
    var subject = "Nouveau Abonnée"
    var nom = "----"
    var email = this.formC.value.email
    var telephone = "----"
    var message = "----"
    let obj ={subject:subject, nom:nom, email:email, telephone:telephone, message:message}

    this.serv2.envoyerEmail(obj).subscribe(res => {
      if(res.status){
        alert("Votre email est envoyée") 
      }else{
        alert("Votre email est annulée") 
      }
    }, err =>{
       alert("erreur")
    })
  }
}

controleInput(obj){
  if(obj.email == ""){
    alert("SVP, inserez votre email") 
    return false
  }
   
  return true
}


  
}
