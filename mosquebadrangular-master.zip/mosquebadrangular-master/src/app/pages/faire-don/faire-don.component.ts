import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-faire-don',
  templateUrl: './faire-don.component.html',
  styleUrls: ['./faire-don.component.scss']
})
export class FaireDonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
