import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mecque',
  templateUrl: './mecque.component.html',
  styleUrls: ['./mecque.component.scss']
})
export class MecqueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
