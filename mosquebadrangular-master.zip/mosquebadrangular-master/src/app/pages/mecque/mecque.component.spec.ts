import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MecqueComponent } from './mecque.component';

describe('MecqueComponent', () => {
  let component: MecqueComponent;
  let fixture: ComponentFixture<MecqueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MecqueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MecqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
