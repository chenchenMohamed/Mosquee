import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JoursHijjaComponent } from './jours-hijja.component';

describe('JoursHijjaComponent', () => {
  let component: JoursHijjaComponent;
  let fixture: ComponentFixture<JoursHijjaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JoursHijjaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JoursHijjaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
