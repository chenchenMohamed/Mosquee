import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jours-hijja',
  templateUrl: './jours-hijja.component.html',
  styleUrls: ['./jours-hijja.component.scss']
})
export class JoursHijjaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
