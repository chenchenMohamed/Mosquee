import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UsersService } from '../../services/users.service';


@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {
  formC:FormGroup
 
  constructor(private fb:FormBuilder, private serv:UsersService) { }

  ngOnInit(): void {
    this.formC=this.fb.group({
      nom:['',[Validators.required]],
      email:['',[Validators.required]],
      subject:['',[Validators.required]],
      telephone:['',[Validators.required]],
      message:['',[Validators.required]],
    })
  }
isLoading = false
  envoyerMessage(){
    if(this.controleInput(this.formC.value) && !this.isLoading){
      this.isLoading = true 
      this.serv.envoyerEmail(this.formC.value).subscribe(res => {
        if(res.status){
          this.isLoading = false 
          alert("email envoyer") 
        }else{
          this.isLoading = false 
          alert("email annuler") 
        }
      }, err =>{
        this.isLoading = false
         alert("erreur")
      })
    }
  }

  controleInput(obj){
    if(obj.nom == ""){
      alert("SVP, inserez votre nom") 
      return false
    }else if(obj.email == ""){
      alert("SVP, inserez votre email") 
      return false
    }else if(obj.subject == ""){
      alert("SVP, inserez votre sujet") 
      return false
    }else if(obj.telephone == ""){
        alert("SVP, inserez le numéro de votre télephone") 
        return false
    }else if(obj.message == ""){
        alert("SVP, inserez votre message") 
        return false
    }
     
    return true
  }
  
}

