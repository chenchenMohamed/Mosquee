import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PhotosMosqueComponent } from './photos-mosque.component';

describe('PhotosMosqueComponent', () => {
  let component: PhotosMosqueComponent;
  let fixture: ComponentFixture<PhotosMosqueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PhotosMosqueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PhotosMosqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
