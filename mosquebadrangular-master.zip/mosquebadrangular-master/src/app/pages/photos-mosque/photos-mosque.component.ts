import { Component, OnInit } from '@angular/core';

import { PhotosService } from '../../services/photos.service';
@Component({
  selector: 'app-photos-mosque',
  templateUrl: './photos-mosque.component.html',
  styleUrls: ['./photos-mosque.component.scss']
})
export class PhotosMosqueComponent implements OnInit {
  tabListe = []
  constructor(private serv:PhotosService) { }

  ngOnInit(): void {
    this.serv.listAll().subscribe(res => {
      if(res.status){
        this.tabListe = res.resultat
      }
    })
  }

}
