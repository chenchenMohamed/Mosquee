import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccueilComponent } from './pages/accueil/accueil.component'; 
import { FetesComponent } from './pages/fetes/fetes.component'; 
import { HoraireDesPrieresComponent } from './pages/horaire-des-prieres/horaire-des-prieres.component'; 
import { IslamComponent } from './pages/islam/islam.component'; 
import { MissionActivitesComponent } from './pages/mission-activites/mission-activites.component';
import { PresentationComponent } from './pages/presentation/presentation.component';
import { FaireDonComponent } from './pages/faire-don/faire-don.component';

import { LoginComponent } from './admin/login/login.component';
import { ProfilComponent } from './admin/profil/profil.component';
import { ActualitesComponent } from './admin/actualites/actualites.component';
import { ActivitesComponent } from './admin/activites/activites.component';
import { CommuniquesComponent } from './admin/communiques/communiques.component';
import { PhotosComponent } from './admin/photos/photos.component';
import { VideosComponent } from './admin/videos/videos.component';

import { MecqueComponent } from './pages/mecque/mecque.component';
import { SunnaComponent } from './pages/sunna/sunna.component';
import { CoranComponent } from './pages/coran/coran.component';
import { ProphetesComponent } from './pages/prophetes/prophetes.component';
import { InvocationsComponent } from './pages/invocations/invocations.component';
import { JoursHijjaComponent } from './pages/jours-hijja/jours-hijja.component';
import { ActualitesMosqueComponent } from './pages/actualites-mosque/actualites-mosque.component';
import { VideosMosqueComponent } from './pages/videos-mosque/videos-mosque.component';
import { PhotosMosqueComponent } from './pages/photos-mosque/photos-mosque.component';
import { CommuniquesMosqueComponent } from './pages/communiques-mosque/communiques-mosque.component';
import { RegulieusesComponent } from './admin/regulieuses/regulieuses.component';
import { SadakaComponent } from './pages/sadaka/sadaka.component';
import { ContactComponent } from './pages/contact/contact.component';
import { JoursComponent } from './admin/jours/jours.component';

const routes: Routes = [
  {path: '',redirectTo:'Accueil',pathMatch:"full"},

  {path: 'Accueil' , component: AccueilComponent },
  {path: 'sadaka' , component: SadakaComponent },
  {path: 'contact' , component: ContactComponent },
  {path: 'Fetes' , component: FetesComponent },
  {path: 'Horaires-prieres' , component: HoraireDesPrieresComponent },
  {path: 'actualitesMosquee' , component: ActualitesMosqueComponent },
  {path: 'Missions-activites' , component: MissionActivitesComponent },
  {path: 'Présentation' , component: PresentationComponent },
  {path: 'Faire-Don' , component: FaireDonComponent },

  {path: 'communiquesMosquee' , component: CommuniquesMosqueComponent },
  {path: 'photosMosquee' , component: PhotosMosqueComponent },
  {path: 'videosMosquee' , component: VideosMosqueComponent },
  
  {path: 'mecque' , component: MecqueComponent },
  {path: 'sunna' , component: SunnaComponent },
  {path: 'coran' , component: CoranComponent },
  {path: 'prophetes' , component: ProphetesComponent },
  {path: 'invocations' , component: InvocationsComponent },
  {path: 'joursHijja' , component: JoursHijjaComponent },
  {path: 'islam' , component: IslamComponent },

  {path: 'login' , component: LoginComponent },
  {path: 'profil' , component: ProfilComponent },
  {path: 'actualites' , component: ActualitesComponent },
  {path: 'activites' , component: ActivitesComponent },
  {path: 'communiques' , component: CommuniquesComponent },
  {path: 'photos' , component: PhotosComponent },
  {path: 'videos' , component: VideosComponent },
  {path: 'regulieuses' , component: RegulieusesComponent },
  {path: 'jours' , component: JoursComponent },
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
