import { Component, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { CommuniquesService } from '../../services/communiques.service';
import { DeleteCommuniqueComponent } from '../delete-communique/delete-communique.component';
import { AddCommuniqueComponent } from '../add-communique/add-communique.component';
import { UpdateCommuniqueComponent } from '../update-communique/update-communique.component';

@Component({
  selector: 'app-communiques',
  templateUrl: './communiques.component.html',
  styleUrls: ['./communiques.component.scss']
})
export class CommuniquesComponent implements OnInit {

  tabListe = []
  page=1
  totalPage = 1
  
  constructor(private modalService: NgbModal, private router : Router, private serv:CommuniquesService,) { 
    this.serv.loadingChange.subscribe(res =>{
      this.getList()
    })
  }

  ngOnInit(): void {
  }

  getList(){
    let request = {page:this.page}
    this.serv.list(request).subscribe(res => {
      if(res.status){
        if(res.resultat.docs.length == 0 && res.resultat.page > 1 ){
          this.setPage(res.resultat.page - 1)
        }else{
          this.tabListe = res.resultat.docs
          this.serv.setListe(this.tabListe)
          this.totalPage = res.resultat.pages
          this.page = res.resultat.page
    
          console.log(res)
        }
      }
    })  
  }

  
  openAjouter() {
    const modalRef = this.modalService.open(AddCommuniqueComponent);
    modalRef.componentInstance.name = 'World';
  }

  openUpdate(event) {
    this.serv.id = event.target.id
    const modalRef = this.modalService.open(UpdateCommuniqueComponent);
    modalRef.componentInstance.name = 'World';
  }

  openDelete(event) {
    this.serv.id = event.target.id
    const modalRef = this.modalService.open(DeleteCommuniqueComponent);
    modalRef.componentInstance.name = 'World';
  }

  setPage(newPage: number) {
    this.page = newPage
    this.getList()
  }


}

