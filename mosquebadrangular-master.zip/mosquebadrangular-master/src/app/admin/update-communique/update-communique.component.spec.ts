import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateCommuniqueComponent } from './update-communique.component';

describe('UpdateCommuniqueComponent', () => {
  let component: UpdateCommuniqueComponent;
  let fixture: ComponentFixture<UpdateCommuniqueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateCommuniqueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateCommuniqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
