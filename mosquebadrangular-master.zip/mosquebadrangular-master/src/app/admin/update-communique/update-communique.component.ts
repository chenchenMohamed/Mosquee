import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommuniquesService } from '../../services/communiques.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-update-communique',
  templateUrl: './update-communique.component.html',
  styleUrls: ['./update-communique.component.scss']
})
export class UpdateCommuniqueComponent implements OnInit {

  formE:FormGroup

  public imagePath;
  imgURL: any;
  public message: string;
  
  constructor(private serv:CommuniquesService,private Fb:FormBuilder, public activeModal: NgbActiveModal) { }
  
  actualite
  ngOnInit() {
    this.actualite = this.serv.getItem()
    this.imgURL = this.actualite.image
    this.formE=this.Fb.group({
     titre:[this.actualite.titre,[Validators.required]],
     description:[this.actualite.description,[Validators.required]],
     date:[this.actualite.date,[Validators.required]],
     image:[this.actualite.image,[Validators.required]],

    })

  }
  

  multiImage
  selectedM(event) {
     this.multiImage = event.target.files;
     var files = event.target.files;
     if (files.length === 0)
     return;

     var mimeType = files[0].type;
     if (mimeType.match(/image\/*/) == null) {
       this.message = "Only images are supported.";
       return;
     }

     var reader = new FileReader();
     this.imagePath = files;
     reader.readAsDataURL(files[0]); 
     reader.onload = (_event) => { 
       this.imgURL = reader.result; 
     }

  }

modifier(){
   const formData = new FormData();
  if(this.multiImage){
    
    for (let img of this.multiImage)
      formData.append('myFiles', img)
      this.serv.createImg(formData).subscribe(res => {
      
      let obj = this.formE.value
      obj.image = res[0]
     
      this.serv.update(obj).subscribe(res => {
        if(res.status){
          this.serv.setLoading()
          alert("Votre modification est enregistreé")
        //  this.formC.reset()
        }
      })
    })
    
  }else{
   
      this.serv.update(this.formE.value).subscribe(res => {
        if(res.status){
          this.serv.setLoading()
          alert("Votre modification est enregistreé")
        //  this.formC.reset()
        }
      })
  }

  this.activeModal.close()
}


}