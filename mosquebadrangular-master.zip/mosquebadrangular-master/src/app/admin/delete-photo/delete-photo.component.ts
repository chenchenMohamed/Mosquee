import { Component, OnInit } from '@angular/core';
import { PhotosService } from './../../services/photos.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-delete-photo',
  templateUrl: './delete-photo.component.html',
  styleUrls: ['./delete-photo.component.scss']
})
export class DeletePhotoComponent implements OnInit {
  constructor(private serv:PhotosService, public activeModal: NgbActiveModal) { }

  actualite

  ngOnInit(): void {
  this.actualite = this.serv.getItem()
  }

  supprimer(){
    this.serv.supprimer().subscribe(res =>{
      alert("Votre suppression est enregistreé")
      this.serv.setLoading()
      this.activeModal.close()  
    },err =>{
      alert("erreur")
    })
  }

  

}