import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { VideosService } from '../../services/videos.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-add-video',
  templateUrl: './add-video.component.html',
  styleUrls: ['./add-video.component.scss']
})
export class AddVideoComponent implements OnInit {

  formE:FormGroup

  public imagePath;
  imgURL: any;
  public message: string;
  
  constructor(private serv:VideosService,private Fb:FormBuilder, public activeModal: NgbActiveModal) { }
  
  ngOnInit() {
    this.formE=this.Fb.group({
     titre:['',[Validators.required]],
     description:['',[Validators.required]],
     date:['',[Validators.required]],
    urlVideo:['',[Validators.required]],
    })

  }
  

  

  ajouter(){
     
      this.serv.new(this.formE.value).subscribe(res => {
        if(res.status){
          this.serv.setLoading()
          alert("Votre ajoutation est enregistreé")
        //  this.formC.reset()
        }
      })
    
    this.activeModal.close()
  }

}

