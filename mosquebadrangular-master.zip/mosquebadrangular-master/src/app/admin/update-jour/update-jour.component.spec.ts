import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateJourComponent } from './update-jour.component';

describe('UpdateJourComponent', () => {
  let component: UpdateJourComponent;
  let fixture: ComponentFixture<UpdateJourComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateJourComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateJourComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
