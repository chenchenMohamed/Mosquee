import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { JoursService } from '../../services/jours.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-update-jour',
  templateUrl: './update-jour.component.html',
  styleUrls: ['./update-jour.component.scss']
})
export class UpdateJourComponent implements OnInit {
  formE:FormGroup


  
  constructor(private serv:JoursService,private Fb:FormBuilder, public activeModal: NgbActiveModal) { }
  
  jour
  ngOnInit() {
    this.jour = this.serv.getItem()
    
    this.formE=this.Fb.group({

      fajr:[this.jour.fajr,[Validators.required]],
      sunrise:[this.jour.sunrise,[Validators.required]],
      dhuhr:[this.jour.dhuhr,[Validators.required]],
      asr:[this.jour.asr,[Validators.required]],
      maghrib:[this.jour.maghrib,[Validators.required]],
      isha:[this.jour.isha,[Validators.required]],
      imsak:[this.jour.imsak,[Validators.required]],
      
      date:[this.jour.date,[Validators.required]],
      day:[this.jour.day,[Validators.required]],
      month:[this.jour.month,[Validators.required]],
      year:[this.jour.year,[Validators.required]],
      
      dayString:[this.jour.dayString,[Validators.required]],
      monthString:[this.jour.monthString,[Validators.required]],
  
      dateHijri:[this.jour.dateHijri,[Validators.required]],
      monthHijriString:[this.jour.monthHijriString,[Validators.required]],
      
      monthHijri:[this.jour.monthHijri,[Validators.required]],
      dayHijri:[this.jour.dayHijri,[Validators.required]],
      yearHijri:[this.jour.yearHijri,[Validators.required]],
    
    })

  }
  

 
modifier(){
   
      this.serv.update(this.formE.value).subscribe(res => {
        if(res.status){
          this.serv.setLoading()
          alert("Votre modification est enregistreé")
        //  this.formC.reset()
        }
      },err=>{
        alert("Erreur")
      })
 
  this.activeModal.close()
}


}