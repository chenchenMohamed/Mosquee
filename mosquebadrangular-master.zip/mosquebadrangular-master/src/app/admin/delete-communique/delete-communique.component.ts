import { Component, OnInit } from '@angular/core';
import { CommuniquesService } from './../../services/communiques.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-delete-communique',
  templateUrl: './delete-communique.component.html',
  styleUrls: ['./delete-communique.component.scss']
})
export class DeleteCommuniqueComponent implements OnInit {
  constructor(private serv:CommuniquesService, public activeModal: NgbActiveModal) { }

  actualite

  ngOnInit(): void {
  this.actualite = this.serv.getItem()
  }

  supprimer(){
    this.serv.supprimer().subscribe(res =>{
      alert("Votre suppression est enregistreé")
      this.serv.setLoading()
      this.activeModal.close()  
    },err =>{
      alert("erreur")
    })
  }

  

}