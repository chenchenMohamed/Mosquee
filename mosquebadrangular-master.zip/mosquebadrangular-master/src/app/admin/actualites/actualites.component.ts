import { Component, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { ActualitesService } from '../../services/actualites.service';
import { DeleteActualiteComponent } from '../delete-actualite/delete-actualite.component';
import { AddActualiteComponent } from '../add-actualite/add-actualite.component';
import { UpdateActualiteComponent } from '../update-actualite/update-actualite.component';

@Component({
  selector: 'app-actualites',
  templateUrl: './actualites.component.html',
  styleUrls: ['./actualites.component.scss']
})
export class ActualitesComponent implements OnInit {

  tabActualites = []
  page=1
  totalPage = 1
  
  constructor(private modalService: NgbModal, private router : Router, private serv:ActualitesService,) { 
    this.serv.loadingChange.subscribe(res =>{
      this.getList()
    })
  }

  ngOnInit(): void {
  }

  getList(){
    let request = {page:this.page}
    this.serv.list(request).subscribe(res => {
      if(res.status){
        if(res.resultat.docs.length == 0 && res.resultat.page > 1 ){
          this.setPage(res.resultat.page - 1)
        }else{
          this.tabActualites = res.resultat.docs
          this.serv.setListe(this.tabActualites)
          this.totalPage = res.resultat.pages
          this.page = res.resultat.page
    
          console.log(res)
        }
      }
    })  
  }

  
  openAjouter() {
    const modalRef = this.modalService.open(AddActualiteComponent);
    modalRef.componentInstance.name = 'World';
  }

  openUpdate(event) {
    this.serv.id = event.target.id
    const modalRef = this.modalService.open(UpdateActualiteComponent);
    modalRef.componentInstance.name = 'World';
  }

  openDelete(event) {
    this.serv.id = event.target.id
    const modalRef = this.modalService.open(DeleteActualiteComponent);
    modalRef.componentInstance.name = 'World';
  }

  setPage(newPage: number) {
    this.page = newPage
    this.getList()
  }


}
