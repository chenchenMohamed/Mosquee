import { Component, OnInit } from '@angular/core';
import { ActivitesService } from '../../services/activites.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-delete-activite',
  templateUrl: './delete-activite.component.html',
  styleUrls: ['./delete-activite.component.scss']
})
export class DeleteActiviteComponent implements OnInit {

  constructor(private serv:ActivitesService, public activeModal: NgbActiveModal) { }

  item

  ngOnInit(): void {
  this.item = this.serv.getItem()
  }

  supprimer(){
    this.serv.supprimer().subscribe(res =>{
      alert("Votre suppression est enregistreé")
      this.serv.setLoading()
      this.activeModal.close()  
    },err =>{
      alert("erreur")
    })
  }

  

}
