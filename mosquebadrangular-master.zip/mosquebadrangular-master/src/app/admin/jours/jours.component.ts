import { Component, OnInit } from '@angular/core';
import { JoursService } from '../../services/jours.service';
declare var $: any;
import {formatDate} from '@angular/common';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UpdateJourComponent } from '../update-jour/update-jour.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-jours',
  templateUrl: './jours.component.html',
  styleUrls: ['./jours.component.scss']
})
export class JoursComponent implements OnInit {

  constructor(private modalService: NgbModal,private serv:JoursService, private Fb:FormBuilder) {
    
   }
   loading = false

   numberFajr = 0;
   numberSunrise = 0;
   numberDhuhr = 0;
   numberAsr = 0;
   numberMaghrib = 0;
   numberIsha = 0;
   numberImsak = 0;

   incrementFajr(nbr){
    this.numberFajr += nbr
    if(this.numberFajr == -60){ 
      this.numberFajr += 1
    }

    if(this.numberFajr == 60){
      this.numberFajr -= 1
    }
   }

  incrementSunrise(nbr){
    this.numberSunrise += nbr
    if(this.numberSunrise == -60){ 
      this.numberSunrise += 1
    }

    if(this.numberSunrise == 60){
      this.numberSunrise -= 1
    }
  }

   incrementDhuhr(nbr){
    this.numberDhuhr += nbr
    if(this.numberDhuhr == -60){ 
      this.numberDhuhr += 1
    }

    if(this.numberDhuhr == 60){
      this.numberDhuhr -= 1
    } 
   }

   incrementAsr(nbr){
    this.numberAsr += nbr
    if(this.numberAsr == -60){ 
      this.numberAsr += 1
    }

    if(this.numberAsr == 60){
      this.numberAsr -= 1
    } 
   }

   incrementMaghrib(nbr){
    this.numberMaghrib += nbr
    if(this.numberMaghrib == -60){ 
      this.numberMaghrib += 1
    }

    if(this.numberMaghrib == 60){
      this.numberMaghrib -= 1
    } 
   }

   incrementIsha(nbr){
    this.numberIsha += nbr
    if(this.numberIsha == -60){ 
      this.numberIsha += 1
    }

    if(this.numberIsha == 60){
      this.numberIsha -= 1
    } 
   }

   incrementImsak(nbr){
    this.numberImsak += nbr
    if(this.numberImsak == -60){ 
      this.numberImsak += 1
    }

    if(this.numberImsak == 60){
      this.numberImsak -= 1
    } 
   }
   
   compareDates(dateDebut, dateFin){
       var mois1 = dateDebut.substring(5,7)
       var jours1 = dateDebut.substring(8,10) 
       
       var moisNumber1 = +mois1
       var joursNumber1 = +jours1
   
       var mois2 = dateFin.substring(5,7)
       var jours2 = dateFin.substring(8,10) 
       
       var moisNumber2 = +mois2
       var joursNumber2 = +jours2
   
       if(moisNumber2 < moisNumber1){
         return false
       }else if((moisNumber2 == moisNumber1) && (joursNumber2 < joursNumber1)){
         return false
       }
       return true
   }

   ModiferLesPreieres(){

    if(this.formE.value.dateDebut == ""){
      alert("SVP, inserer la date de debut")
      return false
    }else if(this.formE.value.dateFin == ""){
      alert("SVP, inserer la date de fin")
      return false
    }else if(!this.compareDates(this.formE.value.dateDebut, this.formE.value.dateFin)){
      alert("SVP, inserer la date de fin superieur a date de debut")
      return false
    }

    const request = {dateDebut:this.formE.value.dateDebut, dateFin:this.formE.value.dateFin, fajr:this.numberFajr, sunrise:this.numberSunrise, dhuhr:this.numberDhuhr, asr:this.numberAsr, maghrib:this.numberMaghrib, isha:this.numberIsha, imsak:this.numberImsak}
    
    if(this.loading){
      return true
    }

    this.loading = true
    this.serv.updateAll(request).subscribe(res => {
      if(res.status){
        this.serv.setLoading()
        alert("Votre modification est enregistreé")
      //  this.formC.reset()*
        this.loading = false
      }else{
        this.loading = false
      }
    },err=>{
      alert("Erreur")
      this.loading = false
    })

   }

  tabJoursOriginal = []
  tabJours = []
  mois = "1"
  date = formatDate(new Date(), 'dd-MM-yyyy', 'en');
  dayNow
  
  formE
  
  ngOnInit(): void {
    this.serv.loadingChange.subscribe(res =>{
      this.chargerJours()
    })

    this.formE=this.Fb.group({
      dateDebut:["",[Validators.required]],
      dateFin:["",[Validators.required]],
    })
  }

  chargerJours(){
    this.tabJoursOriginal = []
    this.tabJours = []

    var moisVersion1  = this.date.substring(3,6)
    var position = moisVersion1.indexOf("-")
    this.mois = moisVersion1.substring(0,position)
    $('#'+this.mois).addClass("style-li-active")
       
    this.serv.listJours().subscribe(res=>{
       
       this.tabJoursOriginal = res.resultat
       this.serv.setListe(this.tabJoursOriginal)
       var tabJoursCopie = this.tabJoursOriginal
       
       for(let i=0; i<tabJoursCopie.length; i++){
          if(tabJoursCopie[i].date == this.date){
             this.dayNow = tabJoursCopie[i]
             this.dayNow.isNow = true
             this.tabJoursOriginal[i] = this.dayNow   
          }else{
            var dayNow2 = tabJoursCopie[i]
            dayNow2.isNow = false
            this.tabJoursOriginal[i] = dayNow2
          }
       }

       this.tabJours = tabJoursCopie.filter(x => x.month == this.mois)    
       
    })

   
  }

  changeMois(event){
    $('#'+this.date).addClass("style-li-active")
    $('#'+this.mois).removeClass("style-li-active")
    this.mois = event.target.id 
    $('#'+this.mois).addClass("style-li-active")
    var tabJoursCopie = this.tabJoursOriginal
    this.tabJours = tabJoursCopie.filter(x => x.month == this.mois)    
  }  

  modifierJour(event){
    this.serv.id = event.target.id
    const modalRef = this.modalService.open(UpdateJourComponent, {size:"lg"});
    modalRef.componentInstance.name = 'World';
  }

  download(){
    if(this.loading){
      return true
    }

    this.loading = true
    this.serv.downloadAgenda().subscribe(res=>{
      if(res.status){
        this.loading = false
        this.chargerJours()
        alert("Votre nouveaux agenda est enregistrer")
      }else{
        this.loading = false
      }
        
    },err=>{
      alert("Erreur")
      this.loading = false
    })
  }

}
