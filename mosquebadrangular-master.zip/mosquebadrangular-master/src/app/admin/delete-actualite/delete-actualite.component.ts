import { Component, OnInit } from '@angular/core';
import { ActualitesService } from './../../services/actualites.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-delete-actualite',
  templateUrl: './delete-actualite.component.html',
  styleUrls: ['./delete-actualite.component.scss']
})
export class DeleteActualiteComponent implements OnInit {

  constructor(private serv:ActualitesService, public activeModal: NgbActiveModal) { }

  actualite

  ngOnInit(): void {
  this.actualite = this.serv.getItem()
  }

  supprimer(){
    this.serv.supprimer().subscribe(res =>{
      alert("Votre suppression est enregistreé")
      this.serv.setLoading()
      this.activeModal.close()  
    },err =>{
      alert("erreur")
    })
  }

  

}
