import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UsersService } from '../../services/users.service';

@Component({
  selector: 'app-profil',
  templateUrl: './profil.component.html',
  styleUrls: ['./profil.component.scss']
})
export class ProfilComponent implements OnInit {
  formC:FormGroup
  message=""
  submitted=false
  isLoading=false

  constructor(private fb:FormBuilder, private router:Router,private serv:UsersService) { 
    
    this.formC=this.fb.group({
      email:['',[Validators.required, Validators.minLength(1)]],
      password:['',[Validators.required, Validators.minLength(1)]],
      newEmail:['',[Validators.required, Validators.minLength(1)]],
      newPassword:['',[Validators.required, Validators.minLength(1)]],
      validPassword:['',[Validators.required, Validators.minLength(1)]]
    })
  }


  ngOnInit(): void {
  }

  modifier(){
    this.submitted=true
    
    if(this.controleInput(this.formC) && !this.isLoading){
      this.isLoading = true
      this.serv.updateCompte(this.formC.value).subscribe(res => {
        if(res.status){
          this.isLoading = false
          alert("Votres informations sont enregistrer")
        }
      }, err =>{
        this.isLoading = false
        alert(err._body)
      })
    }
  }

  changePassword(event){
     console.log("dddsd")
  }
  controleInput(obj){

    console.log(obj.get("password").status)
    if(obj.get("email").status == "INVALID"){
      alert("SVP, inserer votre password")
      return false
    }else if(obj.get("password").status == "INVALID"){
      alert("SVP, inserer votre email")
      return false
    }else if(obj.get("newEmail").status == "INVALID"){
      alert("SVP, inserer votre nouveaux email")
      return false
    }else if(obj.get("newPassword").status == "INVALID"){
      alert("SVP, inserer votre nouveaux mot de passe")
      return false
    }else if(obj.get("validPassword").status == "INVALID"){
      alert("SVP, inserer votre repetetion de mot de passe")
      return false
    }else if(obj.value.newPassword != obj.value.validPassword){
      alert("Votre repetition de nouveaux mot de passe non valideé")
      return false
    }

    return true
  }

}
