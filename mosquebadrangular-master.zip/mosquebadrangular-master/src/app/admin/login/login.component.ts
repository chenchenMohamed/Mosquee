import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UsersService } from '../../services/users.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  formC:FormGroup
  message=""
  submitted=false
  isLoading=false

  constructor(private fb:FormBuilder, private router:Router,private serv:UsersService) {
    this.formC=this.fb.group({
      email:['',[Validators.required, Validators.minLength(1)]],
      password:['',[Validators.required, Validators.minLength(1)]]
    })
  }

  
  ngOnInit(): void {
  }

  login(){
    this.submitted=true
    
    if(this.controleInput(this.formC) && !this.isLoading){
      this.isLoading = true
      this.serv.login(this.formC.value).subscribe(res => {
        this.isLoading = false
        localStorage.setItem("Role",res.role)
        localStorage.setItem("Token",res.token)
        this.serv.loggIn()  
        this.serv.getRole()
        this.router.navigate(['/actualites'])
      }, err =>{
        this.isLoading = false
        alert(err._body)
      })
    }
  }


  controleInput(obj){
    console.log(obj.get("password").status)
    if(obj.get("password").status == "INVALID"){
      alert("SVP, inserer votre password")
      return false
    }else if(obj.get("email").status == "INVALID"){
      alert("SVP, inserer votre email")
      return false
    } 
    return true
  }
   
}
