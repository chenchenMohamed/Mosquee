import { Component, OnInit } from '@angular/core';
import { VideosService } from './../../services/videos.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-delete-video',
  templateUrl: './delete-video.component.html',
  styleUrls: ['./delete-video.component.scss']
})
export class DeleteVideoComponent implements OnInit {
  constructor(private serv:VideosService, public activeModal: NgbActiveModal) { }

  actualite

  ngOnInit(): void {
  this.actualite = this.serv.getItem()
  }

  supprimer(){
    this.serv.supprimer().subscribe(res =>{
      alert("Votre suppression est enregistreé")
      this.serv.setLoading()
      this.activeModal.close()  
    },err =>{
      alert("erreur")
    })
  }

  

}