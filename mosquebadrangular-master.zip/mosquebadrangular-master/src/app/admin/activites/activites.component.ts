import { Component, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { ActivitesService } from '../../services/activites.service';
import { DeleteActiviteComponent } from '../delete-activite/delete-activite.component';
import { AddActiviteComponent } from '../add-activite/add-activite.component';
import { UpdateActiviteComponent } from '../update-activite/update-activite.component';

@Component({
  selector: 'app-activites',
  templateUrl: './activites.component.html',
  styleUrls: ['./activites.component.scss']
})
export class ActivitesComponent implements OnInit {

  tabListe = []
  page=1
  totalPage = 1
  
  constructor(private modalService: NgbModal, private router : Router, private serv:ActivitesService,) { 
    this.serv.loadingChange.subscribe(res =>{
      this.getList()
    })
  }

  ngOnInit(): void {
  }

  getList(){
    let request = {page:this.page}
    this.serv.list(request).subscribe(res => {
      if(res.status){
        if(res.resultat.docs.length == 0 && res.resultat.page > 1 ){
          this.setPage(res.resultat.page - 1)
        }else{
          this.tabListe = res.resultat.docs
          this.serv.setListe(this.tabListe)
          this.totalPage = res.resultat.pages
          this.page = res.resultat.page
    
          console.log(res)
        }
      }
    })  
  }

  
  openAjouter() {
    const modalRef = this.modalService.open(AddActiviteComponent);
    modalRef.componentInstance.name = 'World';
  }

  openUpdate(event) {
    this.serv.id = event.target.id
    const modalRef = this.modalService.open(UpdateActiviteComponent);
    modalRef.componentInstance.name = 'World';
  }

  openDelete(event) {
    this.serv.id = event.target.id
    const modalRef = this.modalService.open(DeleteActiviteComponent);
    modalRef.componentInstance.name = 'World';
  }

  setPage(newPage: number) {
    this.page = newPage
    this.getList()
  }


}

