import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { JoursService } from '../../services/jours.service';

@Component({
  selector: 'app-regulieuses',
  templateUrl: './regulieuses.component.html',
  styleUrls: ['./regulieuses.component.scss']
})
export class RegulieusesComponent implements OnInit {

  formE:FormGroup

  item
  
  constructor(private serv:JoursService,private Fb:FormBuilder) { 
    this.formE=this.Fb.group({
      alIsra:["",[Validators.required]],
      premierRamadan:["",[Validators.required]],
      nuitDuDestin:["",[Validators.required]],
      aidElFitr:["",[Validators.required]],
      aidAlAdha:["",[Validators.required]],
      premierMoharam:["",[Validators.required]],
      achoura:["",[Validators.required]],
      alMawlidAnnabawi:["",[Validators.required]],
    })
  }

  ngOnInit(): void {
    this.serv.listRegulieuses().subscribe(res => {
      if(res.status){
         var liste = res.resultat
         if(liste.length>0){
           this.item = liste[0]
           console.log(this.item)
           this.formE=this.Fb.group({
              alIsra:[this.item.alIsra,[Validators.required]],
              premierRamadan:[this.item.premierRamadan,[Validators.required]],
              nuitDuDestin:[this.item.nuitDuDestin,[Validators.required]],
              aidElFitr:[this.item.aidElFitr,[Validators.required]],
              aidAlAdha:[this.item.aidAlAdha,[Validators.required]],
              premierMoharam:[this.item.premierMoharam,[Validators.required]],
              achoura:[this.item.achoura,[Validators.required]],
              alMawlidAnnabawi:[this.item.alMawlidAnnabawi,[Validators.required]],
           })

         }
      }
    })
  }


  modifier(){
       this.serv.id = this.item.id
       this.serv.updateRegulieuses(this.formE.value).subscribe(res => {
         if(res.status){
           alert("Votre modification est enregistreé")
         //  this.formC.reset()
         }
       })
  }
 


}
