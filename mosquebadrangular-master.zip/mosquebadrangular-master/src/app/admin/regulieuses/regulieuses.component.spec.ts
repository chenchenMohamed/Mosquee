import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegulieusesComponent } from './regulieuses.component';

describe('RegulieusesComponent', () => {
  let component: RegulieusesComponent;
  let fixture: ComponentFixture<RegulieusesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegulieusesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegulieusesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
