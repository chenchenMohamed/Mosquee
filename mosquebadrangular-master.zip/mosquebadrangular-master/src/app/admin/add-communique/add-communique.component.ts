import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommuniquesService } from '../../services/communiques.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-add-communique',
  templateUrl: './add-communique.component.html',
  styleUrls: ['./add-communique.component.scss']
})
export class AddCommuniqueComponent implements OnInit {

  formE:FormGroup

  public imagePath;
  imgURL: any;
  public message: string;
  
  constructor(private serv:CommuniquesService,private Fb:FormBuilder, public activeModal: NgbActiveModal) { }
  
  ngOnInit() {
    this.formE=this.Fb.group({
     titre:['',[Validators.required]],
     description:['',[Validators.required]],
     date:['',[Validators.required]],
     image:['',[Validators.required]],
    })

  }
  

  multiImage
  selectedM(event) {
     this.multiImage = event.target.files;
     var files = event.target.files;
     if (files.length === 0)
     return;

     var mimeType = files[0].type;
     if (mimeType.match(/image\/*/) == null) {
       this.message = "Only images are supported.";
       return;
     }

     var reader = new FileReader();
     this.imagePath = files;
     reader.readAsDataURL(files[0]); 
     reader.onload = (_event) => { 
       this.imgURL = reader.result; 
     }

  }

  ajouter(){
   const formData = new FormData();
    for (let img of this.multiImage)
      formData.append('myFiles', img)
      this.serv.createImg(formData).subscribe(res => {

      let obj = this.formE.value
      obj.image = res[0]
     
      this.serv.new(obj).subscribe(res => {
        if(res.status){
          this.serv.setLoading()
          alert("Votre ajoutation est enregistreé")
        //  this.formC.reset()
        }
      })
    })
    this.activeModal.close()
  }

}

