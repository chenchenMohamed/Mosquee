import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { VideosService } from '../../services/videos.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-update-video',
  templateUrl: './update-video.component.html',
  styleUrls: ['./update-video.component.scss']
})
export class UpdateVideoComponent implements OnInit {

  formE:FormGroup

  public imagePath;
  imgURL: any;
  public message: string;
  
  constructor(private serv:VideosService,private Fb:FormBuilder, public activeModal: NgbActiveModal) { }
  
  actualite
  ngOnInit() {
    this.actualite = this.serv.getItem()
    this.imgURL = this.actualite.image
    this.formE=this.Fb.group({
     titre:[this.actualite.titre,[Validators.required]],
     description:[this.actualite.description,[Validators.required]],
     date:[this.actualite.date,[Validators.required]],
     urlVideo:[this.actualite.urlVideo,[Validators.required]],

    })

  }
  

 
modifier(){
   
      this.serv.update(this.formE.value).subscribe(res => {
        if(res.status){
          this.serv.setLoading()
          alert("Votre modification est enregistreé")
        //  this.formC.reset()
        }
      })
 
  this.activeModal.close()
}


}