import { Injectable } from '@angular/core';

import { map } from 'rxjs/operators';
import { UsersService } from './users.service';
import {Http, RequestOptions,Headers} from '@angular/http'
import { BehaviorSubject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class JoursService {

  // baseURL = "http://51.91.157.69:3000"
  baseURL = "http://localhost:3000"

  optionHeader() : RequestOptions{
    let token= localStorage.getItem('Token');
    let headers=new Headers();
    headers.append('Authorization', `Bearer ${token}`);
    let options=new RequestOptions({ headers :headers});
    return options
  }

  constructor(private http:Http, private ser:UsersService) { }

  varLoading=1
   loading=new BehaviorSubject(this.varLoading)
   loadingChange=this.loading.asObservable()
  
   varliste=[]
   liste=new BehaviorSubject(this.varliste)
   listeChange=this.liste.asObservable()

   id 

   getItem(){
     var items = this.varliste.filter(x=> x.id == this.id )
     return items[0]
   }

   setLoading(){
    this.varLoading=1
    this.loading.next(this.varLoading)
   }

   setListe(items){
    this.varliste = items;
    this.liste.next(this.varliste)
   }


  listJours(){
    return this.http.get(this.baseURL+"/jour/listJours").pipe(map(res=>{
      return res.json()
    }))
  }

  update(request){
    return this.http.post(this.baseURL+"/jour/update/"+this.id, request, this.optionHeader()).pipe(map(res=>{
      return res.json()
    }))
  }

  updateAll(request){
    return this.http.post(this.baseURL+"/jour/updateAll", request, this.optionHeader()).pipe(map(res=>{
      return res.json()
    }))
  }

  listRegulieuses(){
    return this.http.get(this.baseURL+"/regulieuses/liste").pipe(map(res=>{
      return res.json()
    }))
  }

  updateRegulieuses(request){
    return this.http.post(this.baseURL+"/regulieuses/update/"+this.id, request, this.optionHeader()).pipe(map(res=>{
      return res.json()
    }))
  }

  getAcceuil(){
    return this.http.get(this.baseURL+"/accueil/listAll").pipe(map(res=>{
      return res.json()
    }))
  }

  downloadAgenda(){
    return this.http.get(this.baseURL+"/jour/newJours", this.optionHeader()).pipe(map(res=>{
      return res.json()
    }))
  }

  

}
