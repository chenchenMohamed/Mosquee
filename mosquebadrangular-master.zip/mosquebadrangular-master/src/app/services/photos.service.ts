import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { UsersService } from './users.service';
import {Http, RequestOptions,Headers} from '@angular/http'
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PhotosService {
  optionHeader() : RequestOptions{
    let token= localStorage.getItem('Token');
    let headers=new Headers();
    headers.append('Authorization', `Bearer ${token}`);
    let options=new RequestOptions({ headers :headers});
    return options
  }

 // baseURL = "http://51.91.157.69:3000"
  baseURL = "http://localhost:3000"

  constructor(private http:Http, private ser:UsersService ) {
  }
  varLoading=1
  loading=new BehaviorSubject(this.varLoading)
  loadingChange=this.loading.asObservable()
 
  varliste=[]
  liste=new BehaviorSubject(this.varliste)
  listeChange=this.liste.asObservable()

  id 

  getItem(){
    var items = this.varliste.filter(x=> x.id == this.id )
    return items[0]
  }

  setLoading(){
   this.varLoading=1
   this.loading.next(this.varLoading)
  }

  setListe(items){
   this.varliste = items;
   this.liste.next(this.varliste)
  }

   createImg(formData){
    return this.http.post(this.baseURL+"/photo/upload",formData, this.optionHeader()).pipe(map(res=>{
       return res.json()
    }))
  }

 

  new(formData){
    return this.http.post(this.baseURL+"/photo/new ", formData, this.optionHeader() ).pipe(map(res=>{
      return res.json()
    }))
  }

  list(request){
    return this.http.post(this.baseURL+"/photo/liste", request).pipe(map(res=>{
      return res.json()
    }))
  }

  listAll(){
    return this.http.post(this.baseURL+"/photo/listeAll", {}).pipe(map(res=>{
      return res.json()
    }))
  }

  supprimer(){
    return this.http.get(this.baseURL+"/photo/supprimer/"+this.id, this.optionHeader()).pipe(map(res=>{
      return res.json()
    }))
  }

  update(formData){
    return this.http.post(this.baseURL+"/photo/update/"+this.id, formData, this.optionHeader()).pipe(map(res=>{
      return res.json()
    }))
  }

   
 
}