import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import {Http, RequestOptions,Headers} from '@angular/http'
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  //baseURL = "http://51.91.157.69:3000"
  baseURL = "http://localhost:3000"


  constructor(private http:Http) {
    this.loggIn()
    this.getRole()
  }
 
  varRole="client"
  role=new BehaviorSubject(this.varRole)
  roleChange=this.role.asObservable()  

  var=false
  log=new BehaviorSubject(this.var)
  logchange=this.log.asObservable()  

  getRole(){
    this.varRole = localStorage.getItem("Role")
    this.role.next(this.varRole) 
  }

  loggIn(){
    if(localStorage.getItem("Token") == undefined){
      this.log.next(false)
      return false 
    }

    if(localStorage.getItem("Token") == null){
      this.log.next(false)
      return false 
    }

   if (localStorage.getItem("Token").length > 10){
    this.log.next(true) 
    return true
   }else{
     this.log.next(false)
     return false
   }
  }

  optionHeader() : RequestOptions{
    let token= localStorage.getItem('Token');
    let headers=new Headers();
    headers.append('Authorization', `Bearer ${token}`);
    let options=new RequestOptions({ headers :headers});
    return options
  }

  login(formData){
    return this.http.post(this.baseURL+"/user/login",formData).pipe(map(res=>{
      return res.json()
    }))
  }
 
  monCompte(){
    return this.http.get(this.baseURL+"/user/details/_id", this.optionHeader()).pipe(map(res=>{
      return res.json()
    }))
  }

  updateCompte(request){
    return this.http.post(this.baseURL+"/user/update", request, this.optionHeader()).pipe(map(res=>{
      return res.json()
    }))
  }

  envoyerEmail(request){
    return this.http.post(this.baseURL+"/email/newEmail", request).pipe(map(res=>{
      return res.json()
    }))
  }

}
