const express=require("express")
const app=express()
const bodyParser=require('body-parser')
const mongoose=require("mongoose")

const { routerJour } = require("./Route/jourRoute")
const { routerActivite } = require("./Route/activiteRoute")
const { routerActualite } = require("./Route/actualiteRoute")
const { routerCommunique } = require("./Route/communiqueRoute")
const { routerPhoto } = require("./Route/photoRoute")
const { routerVideo } = require("./Route/videoRoute")
const { routerUser } = require("./Route/userRoute")
const { routerRegulieuses } = require("./Route/regulieusesRoute")
const { routerAccueil } = require("./Route/accueilRoute")
const { routerEmail } = require("./route/emailRoute")

const cors=require('cors')
mongoose.connect("mongodb://localhost/shopBD",{ useUnifiedTopology: true,useNewUrlParser: true })
.then(console.log("connected to mongodb"))
.catch(err=>console.log(err))

app.use(express.json())

app.use(cors())

app.use('/jour',routerJour)
app.use('/activite',routerActivite)
app.use('/actualite',routerActualite)
app.use('/communique',routerCommunique)
app.use('/photo',routerPhoto)
app.use('/video',routerVideo)
app.use('/user',routerUser)
app.use('/regulieuses',routerRegulieuses)
app.use('/accueil',routerAccueil)
app.use('/email',routerEmail)


app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('uploads'));
app.use('/uploads', express.static(__dirname + '/uploads/'));




app.listen(3000,()=>{
    console.log("server conected to port 3000")
})