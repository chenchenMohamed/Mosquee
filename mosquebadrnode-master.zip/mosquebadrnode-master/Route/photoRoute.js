const {Photo} =require('../Model/photoModel')
const express=require('express')
const router=express.Router()
const jwt = require('jsonwebtoken');
const { User } =require('../Model/userModel')
var multer = require('multer');

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'uploads')
    },
    filename: function (req, file, cb) {
      cb(null, Date.now() + file.originalname)
    }
})

  var upload = multer({ storage: storage })
  router.post('/upload',upload.array('myFiles'),async(req,res)=>{
    const files = req.files
    let arr=[];
  files.forEach(element => {
    
      arr.push("http://localhost:3000/"+element.path)
 
   })
   console.log(arr)
  return res.send(arr)
})




router.post('/new',  verifytoken, async(req,res)=>{
 
    if(req.user.user.role != "admin"){
      return res.status(401).send({status:false})
    }
 
    const photo=new Photo({
        
        titre:req.body.titre,
        description:req.body.description,
        date:req.body.date,
        image:req.body.image,
        numberOfLove:0,
    
    },)
    
    
    const result=await photo.save()
    return res.send({status:true,resultat:result})
})

router.post('/update/:id',  verifytoken, async(req,res)=>{
    if(req.user.user.role != "admin"){
        return res.status(401).send({status:false})
    }
    
    const result= await Photo.findOneAndUpdate({_id:req.params.id},{  titre:req.body.titre,
        description:req.body.description,
        date:req.body.date,
        image:req.body.image,
    })
    
    return res.send({status:true,resultat:result})
})

const myCustomLabels = {
    totalDocs: 'itemCount',
    docs: 'itemsList',
    limit: 'perPage',
    page: 'currentPage',
    nextPage: 'next',
    prevPage: 'prev',
    totalPages: 'pageCount',
    pagingCounter: 'slNo',
    meta: 'paginator'
  };

router.post('/liste',async(req,res)=>{
    
    const options = {
        page: req.body.page,
        limit: 2,
        customLabels: myCustomLabels,
    };

    const result=await Photo.paginate({}, options)
    return res.send({status:true,resultat:result})
})

router.post('/listeAll',async(req,res)=>{
    const result=await Photo.find({})
    return res.send({status:true,resultat:result})
})

router.get('/supprimer/:id', verifytoken, async(req,res)=>{
    
    if(req.user.user.role != "admin"){
        return res.status(401).send({status:false})
    }
  
    if(await Photo.findOneAndDelete({_id:req.params.id})){
        return res.send({status:true})
    }else{
        return res.send({status:false})
    }
})


function verifytoken(req, res, next){
  const bearerHeader = req.headers['authorization'];
  
  if(typeof bearerHeader !== 'undefined'){
 
      const bearer = bearerHeader.split(' ');
      const bearerToken = bearer[1];
      jwt.verify(bearerToken, 'secretkey', (err, authData) => {
          if(err){
              res.sendStatus(403);
          }else{
              req.user = authData;
              next();
          }
      });
  
  }else{
    console.log("etape100");
     res.sendStatus(401);
  }

}

module.exports.routerPhoto=router