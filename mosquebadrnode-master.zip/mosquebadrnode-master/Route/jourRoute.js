const {Jour} =require('../model/jourModel')
const express=require('express')
const router=express.Router()
const jwt = require('jsonwebtoken');
const axios = require('axios')

router.get('/newJours',  verifytoken, async(req,res)=>{

    if(req.user.user.role != "admin"){
        return res.status(401).send({status:false})
    }
     
    const getJours = async (month,year) => {
        try {
          return await axios.get('http://api.aladhan.com/v1/calendarByAddress?address=1%20Rue%20S%C3%A9bastien%20de%20Brossard,%2077100%20Meaux,%20France&method=2&month='+month+'&year='+year)
        } catch (error) {
          console.error(error)
        }
    }
  
    const saveJours = async (month,year) => {
    
        const data = await getJours(month,year)

        for(let day = 0; day < data.data.data.length; day++){
            const dayCompleted = data.data.data[day]; 
           
            let month = "décembre";
            
            if(dayCompleted.date.gregorian.month.en == "January"){
                 month = "janvier";
            }else if(dayCompleted.date.gregorian.month.en == "February"){
                month = "février";
            }else if(dayCompleted.date.gregorian.month.en == "March"){
                month = "mars";
            }else if(dayCompleted.date.gregorian.month.en == "April"){
                month = "avril";
            }else if(dayCompleted.date.gregorian.month.en == "May"){
                month = "mai";
            }else if(dayCompleted.date.gregorian.month.en == "June"){
                month = "juin";
            }else if(dayCompleted.date.gregorian.month.en == "July"){
                month = "juillet";
            }else if(dayCompleted.date.gregorian.month.en == "August"){
                month = "août";
            }else if(dayCompleted.date.gregorian.month.en == "September"){
                month = "septembre";
            }else if(dayCompleted.date.gregorian.month.en == "October"){
                month = "octobre";
            }else if(dayCompleted.date.gregorian.month.en == "November"){
                month = "novembre";
            }
            
            let dayString = "Dimanche";
            
            if(dayCompleted.date.gregorian.weekday.en == "Monday"){
                dayString = "Lundi";
            }else if(dayCompleted.date.gregorian.weekday.en == "Tuesday"){
                dayString = "Mardi";
            }else if(dayCompleted.date.gregorian.weekday.en == "Wednesday"){
                dayString = "Mercredi";
            }else if(dayCompleted.date.gregorian.weekday.en == "Thursday"){
                dayString = "Jeudi";
            }else if(dayCompleted.date.gregorian.weekday.en == "Friday"){
                dayString = "Vendredi";
            }else if(dayCompleted.date.gregorian.weekday.en == "Saturday"){
                dayString = "Samedi";
            }

            const jour=new Jour({
            
                fajr:dayCompleted.timings.Fajr.substring(0, 5),
                sunrise:dayCompleted.timings.Sunrise.substring(0, 5),
                dhuhr:dayCompleted.timings.Dhuhr.substring(0, 5),
                asr:dayCompleted.timings.Asr.substring(0, 5),
                maghrib:dayCompleted.timings.Maghrib.substring(0, 5),
                isha:dayCompleted.timings.Isha.substring(0, 5),
                imsak:dayCompleted.timings.Imsak.substring(0, 5),
                
                date:dayCompleted.date.gregorian.date,
                day:dayCompleted.date.gregorian.day,
                month:dayCompleted.date.gregorian.month.number,
                year:dayCompleted.date.gregorian.year,
                
                dayString:dayString,
                monthString:month,
            
                dateHijri:dayCompleted.date.hijri.date,
                monthHijriString:dayCompleted.date.hijri.month.en,
                
                monthHijri:dayCompleted.date.hijri.month.number,
                dayHijri:dayCompleted.date.hijri.day,
                yearHijri:dayCompleted.date.hijri.year,
            
            },)
            await jour.save();
        }
        
    
    }
    
    const jour=new Jour({
            
        fajr:"T",
        sunrise:"T",
        dhuhr:"T",
        asr:"T",
        maghrib:"T",
        isha:"T",
        imsak:"T",
        
        date:"T",
        day:"T",
        month:"T",
        year:"T",
        
        dayString:"T",
        monthString:"T",
    
        dateHijri:"T",
        monthHijriString:"T",
        
        monthHijri:"T",
        dayHijri:"T",
        yearHijri:"T",
    
    },)
    await jour.save();

    await Jour.collection.drop();

    var datetime = new Date()+"";
    const year = datetime.substring(11, 16);
    
    for (let month = 0; month < 12; month++) {
       
        saveJours(month+1,year);

    }

    return res.send({status:true})

})

router.post('/update/:id',  verifytoken, async(req,res)=>{
    if(req.user.user.role != "admin"){
        return res.status(401).send({status:false})
    }
    
    const result= await Jour.findOneAndUpdate({_id:req.params.id},{ 
        
        fajr:req.body.fajr,
        sunrise:req.body.sunrise,
        dhuhr:req.body.dhuhr,
        asr:req.body.asr,
        maghrib:req.body.maghrib,
        isha:req.body.isha,
        imsak:req.body.imsak,
        
        date:req.body.date,
        day:req.body.day,
        month:req.body.month,
        year:req.body.year,
        
        dayString:req.body.dayString,
        monthString:req.body.monthString,
    
        dateHijri:req.body.dateHijri,
        monthHijriString:req.body.monthHijriString,
        
        monthHijri:req.body.monthHijri,
        dayHijri:req.body.dayHijri,
        yearHijri:req.body.yearHijri,
    
    })
    
    return res.send({status:true,resultat:result})
})


router.post('/updateAll',  verifytoken, async(req,res)=>{
    
    
    if(req.user.user.role != "admin"){
        return res.status(401).send({status:false})
    }

    const numberOfFajr = req.body.fajr;
    const numberOfSunrise = req.body.sunrise;
    const numberOfDhuhr = req.body.dhuhr;
    const numberOfAsr = req.body.asr;
    const numberOfMaghrib = req.body.maghrib;
    const numberOfIsha = req.body.isha;
    const numberOfImsak = req.body.imsak;

    const jours = await Jour.find()

 /*   if(compareDateJour(req.body.dateDebut, "21/10/2020", req.body.dateFin)){ 
       console.log("21/10/2020")
    }
   */ 
    for(let i = 0; i < jours.length; i++){
        if(compareDateJour(req.body.dateDebut, jours[i].date, req.body.dateFin)){ 
            const fajr = calcluTime(numberOfFajr, jours[i].fajr);
            const sunrise = calcluTime(numberOfSunrise, jours[i].sunrise);
            const dhuhr = calcluTime(numberOfDhuhr, jours[i].dhuhr);
            const asr = calcluTime(numberOfAsr, jours[i].asr);
            const maghrib = calcluTime(numberOfMaghrib, jours[i].maghrib);
            const isha = calcluTime(numberOfIsha, jours[i].isha);
            const imsak = calcluTime(numberOfImsak, jours[i].imsak);
    
            await Jour.findOneAndUpdate({_id:jours[i].id},{ 
                
                fajr:fajr,
                sunrise:sunrise,
                dhuhr:dhuhr,
                asr:asr,
                maghrib:maghrib,
                isha:isha,
                imsak:imsak,
                
            })
        }
    }

    return res.send({status:true})
})


router.get('/listJours',async(req,res)=>{
  const result=await Jour.find()
  return res.send({status:true, resultat:result})
})

function compareDateJour(dateDebut, dateJour, dateFin){
    
    var mois1 = dateDebut.substring(5,7)
    var jours1 = dateDebut.substring(8,10) 
    
    var moisNumber1 = +mois1
    var joursNumber1 = +jours1

    var mois2 = dateJour.substring(3,5) 
    var jours2 = dateJour.substring(0,2)

    var moisNumber2 = +mois2
    var joursNumber2 = +jours2

    var mois3 = dateFin.substring(5,7)
    var jours3 = dateFin.substring(8,10) 
    
    var moisNumber3 = +mois3
    var joursNumber3 = +jours3


    if(moisNumber1 > moisNumber2){
        return false
    }else if(moisNumber2 > moisNumber3){
        return false
    }else{
        if((moisNumber1 == moisNumber2) && (joursNumber1 > joursNumber2)){
            return false
        }else  if((moisNumber2 == moisNumber3) && (joursNumber2 > joursNumber3)){
            return false
        }
    }

    return true

}


function calcluTime(nbrMinutes, time){
    var heure1 = time.substring(0,2)
    var minute1 = time.substring(3,5) 

    var heureNumber1 = +heure1
    var minuteNumber1 = +minute1

    minuteNumber1 += nbrMinutes
    
    if(minuteNumber1 > 60){
        heureNumber1++
        minuteNumber1 -= 60
    }else if(minuteNumber1 < 0){
        heureNumber1-- 
        minuteNumber1 += 60
    }
    
    var chaine = ""

    if(minuteNumber1 > 9){
        chaine = "" + minuteNumber1 
    }else{
        chaine = "0" + minuteNumber1 
    }

    if(heureNumber1 > 9){
        chaine = heureNumber1+ ":" + chaine
    }else{
        chaine = "0"+ heureNumber1+ ":" + chaine 
    }

    return chaine;

}

function verifytoken(req, res, next){
    const bearerHeader = req.headers['authorization'];
    
    if(typeof bearerHeader !== 'undefined'){
   
        const bearer = bearerHeader.split(' ');
        const bearerToken = bearer[1];
        jwt.verify(bearerToken, 'secretkey', (err, authData) => {
            if(err){
                res.sendStatus(403);
            }else{
                req.user = authData;
                next();
            }
        });
    
    }else{
       res.sendStatus(401);
    }
  
  }


module.exports.routerJour=router