const {Actualite} =require('../Model/actualiteModel')
const {Communique} =require('../Model/communiqueModel')
const {Photo} =require('../Model/photoModel')
const {Video} =require('../Model/videoModel')
const express=require('express')
const router=express.Router()


router.get('/listAll',async(req,res)=>{
     
    const actualites = await Actualite.find().sort({ field: 'asc', _id: -1 }).limit(4);

    const communiques = await Communique.find().sort({ field: 'asc', _id: -1 }).limit(4);

    const photos = await Photo.find().sort({ field: 'asc', _id: -1 }).limit(3);

    const videos = await Video.find().sort({ field: 'asc', _id: -1 }).limit(3);

    return res.send({status:true, actualites:actualites, communiques:communiques, photos:photos, videos:videos})
})



module.exports.routerAccueil=router