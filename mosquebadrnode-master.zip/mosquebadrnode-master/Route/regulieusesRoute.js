const {Regulieuses} =require('../Model/regulieusesModel')
const express=require('express')
const router=express.Router()
const jwt = require('jsonwebtoken');
const { User } =require('../Model/userModel')




router.post('/new',  verifytoken, async(req,res)=>{
 
    if(req.user.user.role != "admin"){
      return res.status(401).send({status:false})
    }
 
    const regulieuses=new Regulieuses({
        
        alIsra:req.body.alIsra,
        premierRamadan:req.body.premierRamadan,
        nuitDuDestin:req.body.nuitDuDestin,
        aidElFitr:req.body.aidElFitr,
        aidAlAdha:req.body.aidAlAdha,
        premierMoharam:req.body.premierMoharam,
        achoura:req.body.achoura,
        alMawlidAnnabawi:req.body.alMawlidAnnabawi,
    
    },)
    
    const result=await regulieuses.save()
    return res.send({status:true,resultat:result})
})

router.post('/update/:id',  verifytoken, async(req,res)=>{
    
    if(req.user.user.role != "admin"){
        return res.status(401).send({status:false})
    }
    
    const result= await Regulieuses.findOneAndUpdate({_id:req.params.id},{  
        alIsra:req.body.alIsra,
        premierRamadan:req.body.premierRamadan,
        nuitDuDestin:req.body.nuitDuDestin,
        aidElFitr:req.body.aidElFitr,
        aidAlAdha:req.body.aidAlAdha,
        premierMoharam:req.body.premierMoharam,
        achoura:req.body.achoura,
        alMawlidAnnabawi:req.body.alMawlidAnnabawi,
    })
    
    return res.send({status:true,resultat:result})
})


router.get('/liste',async(req,res)=>{
    const result=await Regulieuses.find({})
    return res.send({status:true,resultat:result})
})



function verifytoken(req, res, next){
  const bearerHeader = req.headers['authorization'];
  
  if(typeof bearerHeader !== 'undefined'){
 
      const bearer = bearerHeader.split(' ');
      const bearerToken = bearer[1];
      jwt.verify(bearerToken, 'secretkey', (err, authData) => {
          if(err){
              res.sendStatus(403);
          }else{
              req.user = authData;
              next();
          }
      });
  
  }else{
    console.log("etape100");
     res.sendStatus(401);
  }

}

module.exports.routerRegulieuses=router