const {Activite} =require('../Model/activiteModel')
const express=require('express')
const router=express.Router()
const jwt = require('jsonwebtoken');
const { User } =require('../Model/userModel')
var multer = require('multer');

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'uploads')
    },
    filename: function (req, file, cb) {
      cb(null, Date.now() + file.originalname)
    }
  })

  var upload = multer({ storage: storage })
  router.post('/upload',upload.array('myFiles'),async(req,res)=>{
    const files = req.files
    let arr=[];
  files.forEach(element => {
    
      arr.push("http://localhost:3000/"+element.path)
 
   })
   console.log(arr)
  return res.send(arr)
})




router.post('/new',  verifytoken, async(req,res)=>{
 
    if(req.user.user.role != "admin"){
      return res.status(401).send({status:false})
    }
 
    const activite=new Activite({
        
        titre:req.body.titre,
        description:req.body.description,
        duree:req.body.duree,
        dateDebut:req.body.dateDebut,
        image:req.body.image,
        numberOfLove:"0",
        prix:req.body.prix,
    
    },)
    
    
    const result=await activite.save()
    return res.send({status:true,resultat:result})
})

router.post('/update/:id',  verifytoken, async(req,res)=>{
    if(req.user.user.role != "admin"){
        return res.status(401).send({status:false})
    }
    
    const result= await Activite.findOneAndUpdate({_id:req.params.id},{  
        titre:req.body.titre,
        description:req.body.description,
        duree:req.body.duree,
        dateDebut:req.body.dateDebut,
        image:req.body.image,
        prix:req.body.prix,})
    
    return res.send({status:true,resultat:result})
})


const myCustomLabels = {
    totalDocs: 'itemCount',
    docs: 'itemsList',
    limit: 'perPage',
    page: 'currentPage',
    nextPage: 'next',
    prevPage: 'prev',
    totalPages: 'pageCount',
    pagingCounter: 'slNo',
    meta: 'paginator'
  };

router.post('/liste',async(req,res)=>{
    
    const options = {
        page: req.body.page,
        limit: 2,
        customLabels: myCustomLabels,
    };

    const result=await Activite.paginate({}, options)
    return res.send({status:true,resultat:result})
})

router.post('/listeAll',async(req,res)=>{
    const result=await Activite.find({})
    return res.send({status:true,resultat:result})
})

router.get('/supprimer/:id', verifytoken, async(req,res)=>{
    
    if(req.user.user.role != "admin"){
        return res.status(401).send({status:false})
    }
  
    if(await Activite.findOneAndDelete({_id:req.params.id})){
        return res.send({status:true})
    }else{
        return res.send({status:false})
    }
})


function verifytoken(req, res, next){
  const bearerHeader = req.headers['authorization'];
  
  if(typeof bearerHeader !== 'undefined'){
 
      const bearer = bearerHeader.split(' ');
      const bearerToken = bearer[1];
      jwt.verify(bearerToken, 'secretkey', (err, authData) => {
          if(err){
              res.sendStatus(403);
          }else{
              req.user = authData;
              next();
          }
      });
  
  }else{
     res.sendStatus(401);
  }

}

module.exports.routerActivite=router