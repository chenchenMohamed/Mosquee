const {Video} =require('../Model/videoModel')
const express=require('express')
const router=express.Router()
const jwt = require('jsonwebtoken');
const { User } =require('../Model/userModel')





router.post('/new',  verifytoken, async(req,res)=>{
 
    if(req.user.user.role != "admin"){
      return res.status(401).send({status:false})
    }
 
    const video=new Video({
        
        titre:req.body.titre,
        description:req.body.description,
        date:req.body.date,
        numberOfLove:0,
        urlVideo:req.body.urlVideo
    
    },)
    
    
    const result=await video.save()
    return res.send({status:true,resultat:result})
})

router.post('/update/:id',  verifytoken, async(req,res)=>{
    if(req.user.user.role != "admin"){
        return res.status(401).send({status:false})
    }
    
    const result= await Video.findOneAndUpdate({_id:req.params.id},{  titre:req.body.titre,
        description:req.body.description,
        date:req.body.date,
        urlVideo:req.body.urlVideo
    })
    
    return res.send({status:true,resultat:result})
})



const myCustomLabels = {
    totalDocs: 'itemCount',
    docs: 'itemsList',
    limit: 'perPage',
    page: 'currentPage',
    nextPage: 'next',
    prevPage: 'prev',
    totalPages: 'pageCount',
    pagingCounter: 'slNo',
    meta: 'paginator'
  };

router.post('/liste',async(req,res)=>{
    
    const options = {
        page: req.body.page,
        limit: 2,
        customLabels: myCustomLabels,
    };

    const result=await Video.paginate({}, options)
    return res.send({status:true,resultat:result})
})

router.post('/listeAll',async(req,res)=>{
    const result=await Video.find({})
    return res.send({status:true,resultat:result})
})

router.get('/supprimer/:id', verifytoken, async(req,res)=>{
    
    if(req.user.user.role != "admin"){
        return res.status(401).send({status:false})
    }
  
    if(await Video.findOneAndDelete({_id:req.params.id})){
        return res.send({status:true})
    }else{
        return res.send({status:false})
    }
})


function verifytoken(req, res, next){
  const bearerHeader = req.headers['authorization'];
  
  if(typeof bearerHeader !== 'undefined'){
 
      const bearer = bearerHeader.split(' ');
      const bearerToken = bearer[1];
      jwt.verify(bearerToken, 'secretkey', (err, authData) => {
          if(err){
              res.sendStatus(403);
          }else{
              req.user = authData;
              next();
          }
      });
  
  }else{
    console.log("etape100");
     res.sendStatus(401);
  }

}

module.exports.routerVideo=router