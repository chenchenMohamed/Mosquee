const mongoose=require('mongoose')
const Joi=require('joi')

const Schema = mongoose.Schema

const schemaRegulieuses=mongoose.Schema({
    
    alIsra:{type:String,required:true},
    premierRamadan:{type:String,required:true},
    nuitDuDestin:{type:String,required:true},
    aidElFitr:{type:String,required:true},
    aidAlAdha:{type:String,required:true},
    premierMoharam:{type:String,required:true},
    achoura:{type:String,required:true},
    alMawlidAnnabawi:{type:String,required:true},

},
{ timestamps: true }
)


schemaRegulieuses.method("toJSON", function() {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
});



const Regulieuses=mongoose.model('Regulieuses',schemaRegulieuses)

module.exports.Regulieuses=Regulieuses