const mongoose=require('mongoose')
const Joi=require('joi')
const mongoosePaginate = require('mongoose-paginate');

const Schema = mongoose.Schema

const schemaJour=mongoose.Schema({
    
    fajr:{type:String,required:true},
    sunrise:{type:String,required:true},
    dhuhr:{type:String,required:true},
    asr:{type:String,required:true},
    maghrib:{type:String,required:true},
    isha:{type:String,required:true},
    imsak:{type:String,required:true},
    date:{type:String,required:true},
    
    day:{type:String,required:true},
    month:{type:String,required:true},
    year:{type:String,required:true},
    
    dayString:{type:String,required:true},
    monthString:{type:String,required:true},

    dateHijri:{type:String,required:true},
    monthHijriString:{type:String,required:true},
    monthHijri:{type:String,required:true},
    dayHijri:{type:String,required:true},
    yearHijri:{type:String,required:true},
    
},
{ timestamps: true }
)

schemaJour.method("toJSON", function() {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
  });

  schemaJour.plugin(mongoosePaginate);

const Jour=mongoose.model('Jour',schemaJour)




module.exports.Jour=Jour
