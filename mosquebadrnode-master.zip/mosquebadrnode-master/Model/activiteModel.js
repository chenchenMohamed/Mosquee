const mongoose=require('mongoose')
const Joi=require('joi')
const mongoosePaginate = require('mongoose-paginate');

const Schema = mongoose.Schema

const schemaActivite=mongoose.Schema({
    
    titre:{type:String,required:true},
    description:{type:String,required:true},
    duree:{type:String,required:true},
    dateDebut:{type:String,required:true},
    image:{type:String,required:true},
    numberOfLove:{type:String,required:true},
    prix:{type:String,required:true},

},
{ timestamps: true }
)

schemaActivite.plugin(mongoosePaginate);

schemaActivite.method("toJSON", function() {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
});



const Activite=mongoose.model('Activite',schemaActivite)

module.exports.Activite=Activite