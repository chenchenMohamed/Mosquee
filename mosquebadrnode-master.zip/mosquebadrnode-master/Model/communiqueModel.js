const mongoose=require('mongoose')
const Joi=require('joi')
const mongoosePaginate = require('mongoose-paginate');

const Schema = mongoose.Schema

const schemaCommunique=mongoose.Schema({
    
    titre:{type:String,required:true},
    description:{type:String,required:true},
    date:{type:String,required:true},
    image:{type:String,required:true},
    numberOfLove:{type:Number, default: 0},
    
},
{ timestamps: true }
)

schemaCommunique.plugin(mongoosePaginate);

schemaCommunique.method("toJSON", function() {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
});


const Communique=mongoose.model('Communique',schemaCommunique)

module.exports.Communique=Communique