const mongoose=require('mongoose')
const Joi=require('joi')
const mongoosePaginate = require('mongoose-paginate');

const Schema = mongoose.Schema

const schemaPhoto=mongoose.Schema({
    
    titre:{type:String,required:true},
    description:{type:String,required:true},
    date:{type:String,required:true},
    image:{type:String,required:true},
    numberOfLove:{Number, default: 00},
    
},
{ timestamps: true }
)

schemaPhoto.plugin(mongoosePaginate);

schemaPhoto.method("toJSON", function() {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
});



const Photo=mongoose.model('Photo',schemaPhoto)

module.exports.Photo=Photo