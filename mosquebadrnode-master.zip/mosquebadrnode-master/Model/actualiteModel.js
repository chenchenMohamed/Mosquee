const mongoose=require('mongoose')
const Joi=require('joi')
const mongoosePaginate = require('mongoose-paginate');

const Schema = mongoose.Schema

const schemaActualite=mongoose.Schema({
    
    titre:{type:String,required:true},
    description:{type:String,required:true},
    date:{type:String,required:true},
    image:{type:String,required:true},
    numberOfLove:{type:Number, default: 0},
    
},
{ timestamps: true }
)

schemaActualite.plugin(mongoosePaginate);

schemaActualite.method("toJSON", function() {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
});



const Actualite=mongoose.model('Actualite',schemaActualite)

module.exports.Actualite=Actualite