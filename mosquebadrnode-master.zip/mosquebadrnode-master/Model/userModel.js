const mongoose=require('mongoose')
const Joi=require('joi')
const mongoosePaginate = require('mongoose-paginate');

const schemaUser=mongoose.Schema({
    
    nom: {type: String, default: ""},
    prenom: {type: String, default: ""},
    password: {type: String, default: ""},
    email: {type: String, default: "", unique: true},
    telephone: {type: String, default: ""},
    adresse: {type: String, default: " "},
    ville: {type: String, default: " "},
    pays: {type: String, default: " "},
    role:{type: String, default: "client"},
    isEnabled:{type: String, default: "1"},
    isValid:{type: String, default: "1"}
    }
    ,
    { timestamps: true },
)

schemaUser.plugin(mongoosePaginate);

  schemaUser.method("toJSON", function() {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
  });


const User=mongoose.model('User',schemaUser)






module.exports.User=User
